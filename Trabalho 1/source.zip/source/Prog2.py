import cv2
import numpy as np
import matplotlib.pyplot as plt


def gama_calc(img, v):
    max_level = 255
    img_list = []
    for x in v:
        # Valor Máximo que pode ser assumido
        max = max_level ** x
        img_g = img ** x / max
        img_list.append(img_g)
    return img_list


def img_eql(img):
    h = img.shape[0]
    w = img.shape[1]
    n = h*w
    # São 256 valores entre [0,255]
    nk, bk = np.histogram(img.reshape(n), 256, [0, 256])
    ps = nk / n
    sk = ps.cumsum()
    for i in range(h):
        for j in range(w):
            img[i][j] = 255 * sk[img[i][j]]
    return img


def show_dist(img):
    h = img.shape[0]
    w = img.shape[1]
    n = h * w
    # São 256 valores entre [0,255]
    nk, bk = np.histogram(img.reshape(n), 256, [0, 256])
    # Frequência relativa ao total de pixels
    ps = nk / n
    sk = ps.cumsum()
    plt.hist(img.reshape(n), 256, [0, 256])
    # Ajuste da escala para o nível de maior frequência. Assim os dois gráficos podem ser vistos ao mesmo tempo
    plt.plot(sk*nk.max(), color="green")
    plt.title("Histograma e CDF")
    plt.legend(('CDF', 'Histograma'))
    plt.xlim([0, 256])


img1 = cv2.imread("car.png", cv2.IMREAD_GRAYSCALE)
img2 = cv2.imread("crowd.png", cv2.IMREAD_GRAYSCALE)
img3 = cv2.imread("university.png", cv2.IMREAD_GRAYSCALE)
# Quatro valores definidos para gamma.
G = [0.4, 0.8, 1.25, 2.5]

# Lista com transformações para cada uma das três imagens
list_img1 = gama_calc(img1, G)
list_img2 = gama_calc(img2, G)
list_img3 = gama_calc(img3, G)
# Lista das 12 imagens com realce
L = [list_img1, list_img2, list_img3]

# Não salvar imagem. Mudar para True caso queira salvo.
save = False
# Percorre a lista com as imagens para cada valor de gamma para salvá-las.
for i in range(3):
    for j in range(4):
        if save:
            # Converte para o formato adequado antes de salvar.
            img = np.uint8(255*L[i][j])
            arq = "q2_fig" + str(i+1) + "_g" + str(j+1) + ".png"
            cv2.imwrite(arq, img)
            
img1_eql = img_eql(img1.copy())
img2_eql = img_eql(img2.copy())
img3_eql = img_eql(img3.copy())

# Mostra as Imagens Pedidas. ESC para sair.
print("Apertar ESC para fechar imagens")
while 1:
    cv2.imshow('Melhor Correcao Gamma p/ Imagem 1', L[0][2])
    cv2.imshow('Melhor Correcao Gamma p/ Imagem 2', L[1][0])
    cv2.imshow('Melhor Correcao Gamma p/ Imagem 3', L[2][0])
    cv2.imshow('Imagem Equalizada 1', img1_eql)
    cv2.imshow('Imagem Equalizada 2', img2_eql)
    cv2.imshow('Imagem Equalizada 3', img3_eql)
    k = cv2.waitKey(1) & 0XFF
    if k == 27:
        cv2.destroyAllWindows()
        break

# Mostra Histograma e CDF p/ Imagem Original
plt.figure(1)
show_dist(img1)
# Mostra Histograma e CDF p/ Imagem Equalizada
plt.figure(2)
show_dist(img1_eql)
plt.show()
