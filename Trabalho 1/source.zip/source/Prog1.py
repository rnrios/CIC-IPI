import numpy as np
import cv2


def dec_int(img, n):
    # Toma as dimensões da imagem
    dim_img = img.shape
    # Chama a função de reduzir a imagem
    img_r = img_red(img, dim_img, n)
    # Retorna a interpolação da imagem reduzida
    img_i = img_int(img_r, dim_img, n)

    return img_i


# Função que reduz a imagem
def img_red(img, size, n):
    # Altura da Imagem
    h = size[0]
    # Largura da Imagem
    w = size[1]
    # Reduz as dimensões
    img_r = img[0:h:n, 0:w:n]
    
    return img_r


# Função que interpola a imagem
def img_int(img_r, size, n):
    h = size[0]
    w = size[1]
    d = size[2]
    # Cria a matriz da nova imagem. Conversão para inteiro para garantir níveis de brilho entre 0 e 255.
    img_i = np.uint8(np.zeros((h, w, d)))
    # Substitui a informação da matriz reduzida nas posições da matriz interpolada
    img_i[0:h:n, 0:w:n] = img_r
    # Percorre a matriz preenchida com os valores da matriz reduzida
    for i in range(h):
        for j in range(w):
            # Replica os valores nas posições circundantes
            if i % n == 0 and j % n == 0:
                img_i[i:i + n, j:j + n] = img_i[i, j]
    return img_i


def edge_improv(img):
    # Cria lista
    H = [0, 1, 0, 1, -4, 1, 0, 1, 0, ]
    # Tranforma para numpy array
    H = np.array(H)
    # Transforma para matriz
    H = H.reshape(3, 3)
    # Aplica o filtro Laplaciano
    L = cv2.filter2D(img, cv2.CV_64F, H)
    # Aplica subtração
    img_f = img - L
    # Normalização para float (Nível entre [0,1])
    return img_f / 255


# Tentativa de melhorar a função dec_int
# Em vez de replicar o pixel, faz-se a média entre os circundantes
def dec_int_improv(img, n):
    imgr = img_red(img, img.shape, n)
    n = np.uint8(np.log2(n))
    for k in range(n):
        hr = 2*imgr.shape[0]
        wr = 2*imgr.shape[1]
        dr = imgr.shape[2]
        img_int = np.zeros((hr, wr, dr))
        img_int[0:hr:2, 0:wr:2] = imgr
        for i in range(hr):
            for j in range(wr):
                # Define pixel mais abaixo e à direita
                if i == hr-1 and j == wr-1:
                    img_int[i, j] = img_int[i-1, j-1]
                # Define regra para última coluna
                elif j == wr-1:
                    if i % 2 == 0:
                        img_int[i, j] = img_int[i, j-1]
                    else:
                        img_int[i, j] = (img_int[i-1, j-1] + img_int[i+1, j-1])/2
                # Define regra para última linha
                elif i == hr-1:
                    if j % 2 == 0:
                        img_int[i, j] = img_int[i-1, j]
                    else:
                        img_int[i, j] = (img_int[i-1, j-1] + img_int[i-1, j+1])/2
                # Define regra para os pixels: média entre os adjacentes mais próximos
                elif i % 2 == 0 and j % 2 == 0:
                    if j != wr-2:
                        # Média entre os pixels ao lado
                        img_int[i, j+1] = (img_int[i, j]+img_int[i, j+2])/2
                    if i != hr-2:
                        # Média entre os pixels acima
                        img_int[i+1, j] = (img_int[i, j]+img_int[i+2, j])/2
                    if i != hr-2 and j != wr-2:
                        # Média entre os pixels à esquerda
                        img_int[i+1, j+1] = (img_int[i, j]+img_int[i, j+2])/2
            imgr = img_int
    return np.uint8(img_int)


img = cv2.imread("test80.jpg", cv2.IMREAD_COLOR)
N = 2
# Imagem Reduzida s/ cv.resize(img_red é a função utilizada por dec_int)
img_r1 = img_red(img, img.shape, N)
# Imagem Interpolada s/ cv.resize
img_i1 = dec_int(img, N)
# Imagem reduzida c/ cv.resize
img_r2 = cv2.resize(img, None, fx=1/N, fy=1/N)
# Imagem interpolada c/ cv.resize
img_i2 = cv2.resize(img_r2, None, fx=N, fy=N, interpolation=cv2.INTER_CUBIC)
# Filtro aplicado à imagem s/ cv.resize
img_filt1 = edge_improv(img_i1)
# Filtro aplicado à imagem c/ cv.resize
img_filt2 = edge_improv(img_i2)
# Nova Interpolação
img_int_melhorada = dec_int_improv(img, N)

# Mostra as Imagens Pedidas. ESC para sair.
print("Apertar ESC para fechar imagens")
while 1:
    cv2.imshow('Imagem Interpolada s/ Resize', img_i1)
    k = cv2.waitKey(1) & 0XFF
    if k == 27:
        cv2.destroyAllWindows()
        break
